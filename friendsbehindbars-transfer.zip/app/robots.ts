import type { MetadataRoute } from "next";

export default function robots(): MetadataRoute.Robots {
  return {
    rules: {
      userAgent: "*",
      allow: "/",
      disallow: ["/admin", "/dashboard", "/recipients", "/my-orders", "/favorites"],
    },
    sitemap: "https://friendsbehindbars.com/sitemap.xml",
  };
}
